-- Adminer 4.3.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `patient`;
CREATE TABLE `patient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `patient` (`id`, `name`) VALUES
(3,	'Pacient1'),
(4,	'Pacient2');

DROP TABLE IF EXISTS `procedure`;
CREATE TABLE `procedure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('waiting','done') COLLATE utf8_czech_ci NOT NULL,
  `treatment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `treatment_id` (`treatment_id`),
  CONSTRAINT `procedure_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `procedure_ibfk_2` FOREIGN KEY (`treatment_id`) REFERENCES `treatment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `procedure` (`id`, `status`, `treatment_id`, `user_id`, `patient_id`, `date`) VALUES
(1,	'waiting',	3,	1,	4,	'2017-12-01 00:00:00'),
(2,	'waiting',	3,	1,	4,	'2017-11-30 23:00:00'),
(3,	'waiting',	3,	1,	4,	'0000-00-00 00:00:00'),
(4,	'waiting',	3,	1,	4,	'0000-00-00 00:00:00');

DROP TABLE IF EXISTS `treatment`;
CREATE TABLE `treatment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `treatment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `treatment` (`id`, `name`, `user_id`) VALUES
(1,	'Abdominoplastika',	1),
(3,	'Rhinoplastika',	2),
(4,	'Obnova vlasů',	2);

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `user` (`id`, `username`, `name`) VALUES
(1,	'tester',	'Tonda Tester'),
(2,	'zkousec',	'Jakub Zkousec');

-- 2017-11-29 15:33:21
